
# Chức năng hiển thị quảng cáo => OKE
# Chức năng hiển thị ảnh slides => OKE
# Chức năng phân trang sản phẩm, bài viết => OKE
# Chức năng ẩn bớt phần mô tả bài viết có dấu 3 chấm => OKE
# Chức năng hiển thị sản phẩm bán chạy và sản phẩm nổi bật => OKE
# Làm sao để upload nhiều ảnh lên server => OKE
# Làm sao để khi upload ảnh thì nó show ra => OKE
# Chức năng hiển thị ảnh thumbnail sản phẩm và các sản phẩm liên quan đến sản phẩm => OKE
# Chức năng điều hướng xem tất cả sản phẩm thuộc danh mục khi ở trang home => OKE
# Chức năng sắp xếp => OKE
# Chức năng lọc sản phẩm AJAX => OKE
# Chức năng cập nhật giỏ hàng AJAX => OKE
# Chức năng chọn địa điểm bằng AJAX (Khả thi nhưng phải gọi API từ nguồn ở ngoài vào để xử lí thì ngon hơn là lưu trữ trong DB) => LÀM SAU
# Chức năng tìm kiếm sản phẩm khi submit button search => OKE
# Gợi ý sản phẩm nâng cao => Xử lí AJAX => OKE
# Thiết kế logo cho website VDHSTORE => OKE
# Chức năng gửi mail về khách hàng khi đặt hàng thành công => OKE
# Chức năng nhận tin của shop => OKE
# Chức năng xây dựng link thân thiện => OKE




# Đưa dự án lên server thực


# Kết thúc sơ bộ dự án PHP LARAVEL




# Chức năng ẩn bớt phần mô tả chi tiết của sản phẩm 
# Chức năng comment, review sản phẩm






# Chức năng thay đổi ngôn ngữ anh - việt
# Chức năng hiển thị thông báo notification 
# Chức năng voucher sản phẩm
# Chức năng đăng nhập đăng ký cho user + kết hợp đăng nhập vs google facebook
# Chức năng hiển thị thông tin user + hiển thị thông tin đơn đặt hàng của user đó
# Làm sao để gửi mã OTP về email để xác thực
# Chức năng popup khi thực hiện thao tác gì đó
# Chức năng chatbot, nhắn tin hỗ trợ
# Chức năng bảo mật website 
# Chức năng xem trên mobile
# Chức năng flash sale
# Chức năng thanh toán online
# Chức năng load trang từ từ khi cuộn từ trên xuống



