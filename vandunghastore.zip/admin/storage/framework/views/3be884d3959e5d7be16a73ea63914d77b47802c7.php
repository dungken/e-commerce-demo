
<?php $__env->startSection('title', 'Edit Post'); ?>
<?php $__env->startSection('content'); ?>
    <div id="content" class="container-fluid">
        <div class="card">
            <div class="card-header font-weight-bold">
                Cập nhật sản phẩm
            </div>
            <div class="card-body">
                <form action="<?php echo e(route('product.update', $product->id)); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-6">
                            <div class="form-group">
                                <label for="name">Tên sản phẩm</label>
                                <br>
                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <small class="text-danger"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <input class="form-control" type="text" name="name" id="name"
                                    value="<?php echo e($product->name); ?>">
                            </div>
                            <div class="form-group">
                                <label for="price">Giá</label>
                                <br>
                                <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <small class="text-danger"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <input class="form-control" type="text" name="price" id="price"
                                    value="<?php echo e($product->price); ?>">
                            </div>
                            <div class="form-group">
                                <label for="qty_on_hand">Số lượng có trong kho</label>
                                <br>
                                <?php $__errorArgs = ['qty_on_hand'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <small class="text-danger"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <input class="form-control" type="text" name="qty_on_hand" id="qty_on_hand"
                                    value="<?php echo e($product->qty_on_hand); ?>">
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="form-group">
                                <label for="desc">Mô tả sản phẩm</label>
                                <br>
                                <?php $__errorArgs = ['desc'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <small class="text-danger"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <textarea name="desc" class="form-control" id="desc" cols="30" rows="5"><?php echo e($product->desc); ?></textarea>
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="detail">Chi tiết sản phẩm</label>
                        <br>
                        <?php $__errorArgs = ['detail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="text-danger"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <textarea name="detail" class="form-control" id="detail" cols="30" rows="20"><?php echo e($product->detail); ?></textarea>
                    </div>

                    <div class="form-group">
                        <label for="thumbnail">Hình ảnh đại diện</label>
                        <br>
                        <?php $__errorArgs = ['thumbnail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="text-danger"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <input type="file" id="file-input" name="thumbnail" class="form-control-file mb-2" id="thumbnail">
                        <div id="image-preview-thumbnail">
                            <img class="mt-2 mb-3" src="<?php echo e(url('public/images/300-300.png')); ?>" alt="">
                        </div>
                    </div>
                    <script>
                        document.getElementById("file-input").addEventListener("change", function(event) {
                            var file = event.target.files[0];
                            var reader = new FileReader();
                            reader.onload = function(e) {
                                var imgElement = document.createElement("img");
                                imgElement.src = e.target.result;
                                imgElement.style.maxWidth = "100%";
                                var previewContainer = document.getElementById("image-preview-thumbnail");
                                previewContainer.innerHTML = "";
                                previewContainer.appendChild(imgElement);
                            };
                            reader.readAsDataURL(file);
                        });
                    </script>

                    <div class="form-group">
                        <label for="imgs_relate">Hình ảnh liên quan</label>
                        <br>
                        <?php $__errorArgs = ['imgs_relate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="text-danger"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <input type="file" multiple name="imgs_relate[]" class="form-control-file" id="imgs_relate">
                        <br>
                        <?php $__errorArgs = ['imgs_relate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="text-danger"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <div id="image-preview-imgs-relate">
                            <img class="mt-2 mr-3 border" src="<?php echo e(url('public/images/300-300.png')); ?>" alt="">
                            <img class="mt-2 mr-3" src="<?php echo e(url('public/images/300-300.png')); ?>" alt="">
                            <img class="mt-2 mr-3" src="<?php echo e(url('public/images/300-300.png')); ?>" alt="">
                            <img class="mt-2 mr-3" src="<?php echo e(url('public/images/300-300.png')); ?>" alt="">
                        </div>
                    </div>

                    <script>
                        document.getElementById("imgs_relate").addEventListener("change", function(event) {
                            var files = event.target.files;

                            var previewContainer = document.getElementById("image-preview-imgs-relate");
                            previewContainer.innerHTML = "";

                            for (var i = 0; i < files.length; i++) {
                                var file = files[i];

                                var reader = new FileReader();
                                reader.onload = function(e) {
                                    var imgElement = document.createElement("img");
                                    imgElement.src = e.target.result;
                                    imgElement.style.maxWidth = "100%";
                                    previewContainer.appendChild(imgElement);
                                };
                                reader.readAsDataURL(file);
                            }
                        });
                    </script>

                    <div class="form-group">
                        <label for="type">Thuộc danh mục</label>
                        <br>
                        <?php $__errorArgs = ['catId'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="text-danger"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <select class="form-control" id="type" name="catId">
                            <option value="">Chọn danh mục</option>
                            <?php $__currentLoopData = $list_cat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option <?php echo e($product->cat_id == $cat->id ? 'selected' : ''); ?> value="<?php echo e($cat->id); ?>">
                                    <?php echo e($cat->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="status">Trạng thái</label>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="status" id="inStock" value="inStock"
                                <?php echo e($product->status == 'inStock' ? 'checked' : ''); ?>>
                            <label class="form-check-label" for="inStock">
                                Còn hàng
                            </label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="status" id="soldOut" value="soldOut"
                                <?php echo e($product->status == 'soldOut' ? 'checked' : ''); ?>>
                            <label class="form-check-label" for="soldOut">
                                Hết hàng
                            </label>
                        </div>
                    </div>
                    <button type="submit" name="btn_add_update" value="Thêm mới sản phẩm" class="btn btn-primary">Lưu thay
                        đổi</button>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Project\vandunghastore.com\admin\resources\views/admin/product/edit.blade.php ENDPATH**/ ?>