
<?php $__env->startSection('title', 'Add Post'); ?>
<?php $__env->startSection('content'); ?>
    <div id="content" class="container-fluid">
        <div class="card">
            <?php if(session('status')): ?>
                <div class="alert alert-success"><?php echo e(session('status')); ?></div>
            <?php endif; ?>
            <?php if(session('status_error')): ?>
                <div class="alert alert-danger"><?php echo e(session('status_error')); ?></div>
            <?php endif; ?>
            <div class="card-header font-weight-bold d-flex justify-content-between align-items-center">
                <h5 class="m-0 ">Danh sách bài viết</h5>
                <div class="form-search form-inline">
                    <form action="#" class=" d-flex">
                        <input type="text" name="keyword" value="<?php echo e(request()->keyword); ?>"
                            class="form-control form-search" placeholder="Tìm kiếm bài viết">
                        <input type="submit" name="btn_search" value="Tìm kiếm" class="btn btn-primary">
                    </form>
                </div>
            </div>
            <form action="<?php echo e(route('post.action', $status)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="card-body">
                    <div class="analytic">
                        <a href="<?php echo e(request()->fullUrlWithQuery(['status' => 'public'])); ?>" class="text-primary">Công
                            khai<span class="text-muted">(<?php echo e($cnt_post[0]); ?>)</span></a>
                        <a href="<?php echo e(request()->fullUrlWithQuery(['status' => 'waiting'])); ?>" class="text-primary">Chờ
                            duyệt<span class="text-muted">(<?php echo e($cnt_post[1]); ?>)</span></a>
                        <a href="<?php echo e(request()->fullUrlWithQuery(['status' => 'disable'])); ?>" class="text-primary">Vô hiệu
                            hóa<span class="text-muted">(<?php echo e($cnt_post[2]); ?>)</span></a>
                    </div>
                    <div class="form-action form-inline py-3">
                        <select class="form-control mr-1" id="" name="action">
                            <option value="">Chọn</option>
                            <?php $__currentLoopData = $action; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($k); ?>"><?php echo e($v); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <input type="submit" name="btn_action" value="Áp dụng" class="btn btn-primary">
                    </div>
                    <table class="table table-striped table-checkall">
                        <thead>
                            <tr>
                                <th scope="col">
                                    <input name="checkall" type="checkbox">
                                </th>
                                <th scope="col">#</th>
                                <th scope="col">Ảnh</th>
                                <th scope="col">Tiêu đề</th>
                                <th scope="col">Danh mục</th>
                                <th scope="col">Ngày tạo</th>
                                <?php if($status == 'public' || $status == 'waiting'): ?>
                                    <th scope="col">Tác vụ</th>
                                <?php endif; ?>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(!empty($posts)): ?>
                                <?php
                                    $cnt = 0;
                                ?>
                                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $cnt++;
                                    ?>
                                    <tr>
                                        <td>
                                            <input type="checkbox" name="check_list[]" value="<?php echo e($post->id); ?>">
                                        </td>
                                        <td scope="row"><?php echo e($cnt); ?></td>
                                        <td><img style="max-width: 150px; height: auto;" src="<?php echo e(url($post->thumbnail)); ?>"
                                                alt=""></td>
                                        <td><a href=""><?php echo e(Str::limit($post->title, 50, '...')); ?></a>
                                        </td>
                                        <?php $__currentLoopData = $cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($cat->id == $post->cat_id): ?>
                                                <td><?php echo e($cat->name); ?></td>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <td><?php echo e($post->created_at); ?></td>
                                        <td>
                                            <?php if($status == $post->status): ?>
                                                <a href="<?php echo e(route('post.edit', $post->id)); ?>"
                                                    class="btn btn-success btn-sm rounded-0 text-white" type="button"
                                                    data-toggle="tooltip" data-placement="top" title="Edit"><i
                                                        class="fa fa-edit"></i></a>
                                                <a href="<?php echo e(route('post.delete', $post->id)); ?>"
                                                    class="btn btn-danger btn-sm rounded-0 text-white" type="button"
                                                    data-toggle="tooltip" data-placement="top" title="Delete"
                                                    onclick="return confirm('Bạn có muốn xóa tạm thời bài viết này không?')"><i
                                                        class="fa fa-trash"></i></a>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <tr>
                                    <td class="text-danger" colspan="7">
                                        <strong>Không có bản ghi nào!</strong>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                    <?php if(!empty($posts)): ?>
                        <?php echo e($posts->links()); ?>

                    <?php endif; ?>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Project\vandunghastore.com\admin\resources\views/admin/post/list.blade.php ENDPATH**/ ?>