
<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid py-5">
        <div class="row">
            <div class="col">
                <div class="card text-white bg-primary mb-3" style="max-width: 18rem;">
                    <div class="card-header">ĐƠN HÀNG THÀNH CÔNG</div>
                    <div class="card-body">
                        <h5 class="card-title"><?php echo e($cnt[0]); ?></h5>
                        <p class="card-text">Đơn hàng giao dịch thành công</p>
                    </div>
                </div>
            </div>
            <div class="col">
                <div class="card text-white bg-danger mb-3" style="max-width: 18rem;">
                    <div class="card-header">ĐANG XỬ LÝ</div>
                    <div class="card-body">
                        <h5 class="card-title"><?php echo e($cnt[1]); ?></h5>
                        <p class="card-text">Số lượng đơn hàng đang xử lý</p>
                    </div>
                </div>
            </div>

            <div class="col">
                <div class="card text-white bg-success mb-3" style="max-width: 18rem;">
                    <div class="card-header">DOANH SỐ</div>
                    <div class="card-body">
                        <h5 class="card-title"><?php echo e(number_format($cnt[2], 0, ',', '.')); ?> đ</h5>
                        <p class="card-text">Doanh số hệ thống</p>
                    </div>
                </div>
            </div>
            <div class="col">
                <div class="card text-white bg-dark mb-3" style="max-width: 18rem;">
                    <div class="card-header">ĐƠN HÀNG HỦY</div>
                    <div class="card-body">
                        <h5 class="card-title"><?php echo e($cnt[3]); ?></h5>
                        <p class="card-text">Số đơn bị hủy trong hệ thống</p>
                    </div>
                </div>
            </div>
        </div>
        <!-- end analytic  -->

        <?php if(session('status')): ?>
            <div class="alert alert-success"><?php echo e(session('status')); ?></div>
        <?php endif; ?>

        <div class="card">
            <div class="card-header font-weight-bold">
                ĐƠN HÀNG MỚI
            </div>
            <div class="card-body">
                <table class="table table-striped table-checkall">
                    <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Mã đơn hàng</th>
                            <th scope="col">Mã KH</th>
                            <th scope="col">Khách hàng</th>
                            <th scope="col">Số lượng</th>
                            <th scope="col">Tổng giá</th>
                            <th scope="col">Chi tiết</th>
                            <th scope="col">Trạng thái</th>
                            <th scope="col">Thời gian</th>
                            <th scope="col">Tác vụ</th>
                        </tr>
                    </thead>
                    <tbody>

                        <?php if(!empty($clients)): ?>
                            <?php
                                $cnt = 0;
                            ?>
                            <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $cnt++;
                                    $status_translate = [
                                        'pending' => 'Chờ duyệt',
                                        'approved' => 'Đã duyệt',
                                        'delivering' => 'Đang vận chuyển',
                                        'received' => 'Đã giao',
                                        'paid' => 'Đã thanh toán',
                                    ];
                                ?>
                                <tr>
                                    <td><?php echo e($cnt); ?></td>
                                    <td><?php echo e($client->code_order); ?></td>
                                    <td><?php echo e($client->code_client); ?></td>
                                    <td>
                                        <?php echo e($client->name); ?> <br>
                                        <?php echo e($client->phone); ?> <br>
                                        <?php echo e($client->email); ?>

                                    </td>
                                    <td class="text-center"><?php echo e($client->num_order); ?></td>
                                    <td><?php echo e(number_format($client->total, 0, ',', '.')); ?> đ</td>
                                    <td><a href="<?php echo e(route('order.detail', $client->id)); ?>">Xem chi tiết</a></td>
                                    <?php if($client->status == 'pending'): ?>
                                        <td>
                                            <span
                                                class="badge badge-danger"><?php echo e($status_translate[$client->status]); ?></span>
                                        </td>
                                    <?php elseif($client->status == 'approved'): ?>
                                        <td>
                                            <span class="badge badge-info"><?php echo e($status_translate[$client->status]); ?></span>
                                        </td>
                                    <?php elseif($client->status == 'delivering'): ?>
                                        <td>
                                            <span
                                                class="badge badge-secondary"><?php echo e($status_translate[$client->status]); ?></span>
                                        </td>
                                    <?php elseif($client->status == 'received'): ?>
                                        <td>
                                            <span
                                                class="badge badge-primary"><?php echo e($status_translate[$client->status]); ?></span>
                                        </td>
                                    <?php else: ?>
                                        <td>
                                            <span
                                                class="badge badge-success"><?php echo e($status_translate[$client->status]); ?></span>
                                        </td>
                                    <?php endif; ?>

                                    <td><?php echo e($client->created_at); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('order.delete', $client->id)); ?>"
                                            onclick="return confirm('Bạn có chắc chắn muốn xóa khách hàng này không?'); "
                                            class="btn btn-danger btn-sm rounded-0 text-white" type="button"
                                            data-toggle="tooltip" data-placement="top" title="Delete"><i
                                                class="fa fa-trash"></i></a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <tr>
                                <td class="text-danger" colspan="11">
                                    <strong>Không có bản ghi nào!</strong>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
                <?php if(!empty($clients)): ?>
                    <?php echo e($clients->links()); ?>

                <?php endif; ?>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Project\vandunghastore.com\admin\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>