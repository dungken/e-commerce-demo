
<?php $__env->startSection('title', 'List Order'); ?>
<?php $__env->startSection('content'); ?>

    <div id="content" class="container-fluid">
        <?php if(session('status')): ?>
            <div class="alert alert-success"><?php echo e(session('status')); ?></div>
        <?php endif; ?>
        <?php if(session('status_error')): ?>
            <div class="alert alert-danger"><?php echo e(session('status_error')); ?></div>
        <?php endif; ?>  
        <div class="card">
            <div class="card-header font-weight-bold d-flex justify-content-between align-items-center">
                <h5 class="m-0 ">Danh sách đơn hàng</h5>
                <div class="form-search form-inline">
                    <form action="<?php echo e(route('order.list', $status)); ?>" class="d-flex">
                        <input type="text" name="keyword" class="form-control form-search" placeholder="Tìm kiếm"
                            value="<?php echo e(request()->keyword); ?>">
                        <input type="submit" name="btn-search" value="Tìm kiếm" class="btn btn-primary">
                    </form>
                </div>
            </div>
            <form action="<?php echo e(route('order.action', $status)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="card-body">
                    <div class="analytic">
                        <a href="<?php echo e(request()->fullUrlWithQuery(['status' => 'pending'])); ?>" class="text-primary">Chờ
                            duyệt<span class="text-muted">(<?php echo e($cnt_client[0]); ?>)</span></a>
                        <a href="<?php echo e(request()->fullUrlWithQuery(['status' => 'approved'])); ?>" class="text-primary">Đã
                            duyệt<span class="text-muted">(<?php echo e($cnt_client[1]); ?>)</span></a>
                        <a href="<?php echo e(request()->fullUrlWithQuery(['status' => 'delivering'])); ?>" class="text-primary">Đang
                            giao hàng<span class="text-muted">(<?php echo e($cnt_client[2]); ?>)</span></a>
                        <a href="<?php echo e(request()->fullUrlWithQuery(['status' => 'received'])); ?>" class="text-primary">Đã giao
                            hàng<span class="text-muted">(<?php echo e($cnt_client[3]); ?>)</span></a>
                        <a href="<?php echo e(request()->fullUrlWithQuery(['status' => 'paid'])); ?>" class="text-primary">Đã thanh
                            toán<span class="text-muted">(<?php echo e($cnt_client[4]); ?>)</span></a>
                    </div>

                    <div class="form-action form-inline py-3">
                        <select class="form-control mr-1" id="" name="action">
                            <option value="0">Chọn</option>
                            <?php $__currentLoopData = $action; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $act): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($k); ?>"><?php echo e($act); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <input type="submit" name="btn-action" value="Áp dụng" class="btn btn-primary">
                    </div>

                    <table class="table table-striped table-checkall">
                        <thead>
                            <tr>
                                <th>
                                    <input type="checkbox" name="checkall">
                                </th>
                                <th scope="col">#</th>
                                <th scope="col">Mã đơn hàng</th>
                                <th scope="col">Mã KH</th>
                                <th scope="col">Khách hàng</th>
                                <th scope="col">Số lượng</th>
                                <th scope="col">Tổng giá</th>
                                <th scope="col">Chi tiết</th>
                                <th scope="col">Trạng thái</th>
                                <th scope="col">Thời gian</th>
                                <th scope="col">Tác vụ</th>
                            </tr>
                        </thead>
                        <tbody>

                            <?php if(!empty($clients)): ?>
                                <?php
                                    $cnt = 0;
                                ?>
                                <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $cnt++;
                                        $status_translate = [
                                            'pending' => 'Chờ duyệt',
                                            'approved' => 'Đã duyệt',
                                            'delivering' => 'Đang vận chuyển',
                                            'received' => 'Đã giao',
                                            'paid' => 'Đã thanh toán',
                                        ];
                                    ?>
                                    <tr>
                                        <td>
                                            <input type="checkbox" name="check_list[]" value="<?php echo e($client->id); ?>">
                                        </td>
                                        <td><?php echo e($cnt); ?></td>
                                        <td><?php echo e($client->code_order); ?></td>
                                        <td><?php echo e($client->code_client); ?></td>
                                        <td>
                                            <?php echo e($client->name); ?> <br>
                                            <?php echo e($client->phone); ?> <br>
                                            <?php echo e($client->email); ?>

                                        </td>
                                        <td class="text-center"><?php echo e($client->num_order); ?></td>
                                        <td><?php echo e(number_format($client->total, 0, ',', '.')); ?> đ</td>
                                        <td><a href="<?php echo e(route('order.detail', $client->id)); ?>">Xem chi tiết</a></td>
                                        <?php if($client->status == 'pending'): ?>
                                            <td>
                                                <span
                                                    class="badge badge-danger"><?php echo e($status_translate[$client->status]); ?></span>
                                            </td>
                                        <?php elseif($client->status == 'approved'): ?>
                                            <td>
                                                <span
                                                    class="badge badge-info"><?php echo e($status_translate[$client->status]); ?></span>
                                            </td>
                                        <?php elseif($client->status == 'delivering'): ?>
                                            <td>
                                                <span
                                                    class="badge badge-secondary"><?php echo e($status_translate[$client->status]); ?></span>
                                            </td>
                                        <?php elseif($client->status == 'received'): ?>
                                            <td>
                                                <span
                                                    class="badge badge-primary"><?php echo e($status_translate[$client->status]); ?></span>
                                            </td>
                                        <?php else: ?>
                                            <td>
                                                <span
                                                    class="badge badge-success"><?php echo e($status_translate[$client->status]); ?></span>
                                            </td>
                                        <?php endif; ?>

                                        <td><?php echo e($client->created_at); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('order.delete', $client->id)); ?>"
                                                onclick="return confirm('Bạn có chắc chắn muốn xóa khách hàng này không?'); "
                                                class="btn btn-danger btn-sm rounded-0 text-white" type="button"
                                                data-toggle="tooltip" data-placement="top" title="Delete"><i
                                                    class="fa fa-trash"></i></a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <tr>
                                    <td class="text-danger" colspan="11">
                                        <strong>Không có bản ghi nào!</strong>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                    <?php if(!empty($clients)): ?>
                        <?php echo e($clients->links()); ?>

                    <?php endif; ?>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Project\vandunghastore.com\admin\resources\views/admin/order/list.blade.php ENDPATH**/ ?>