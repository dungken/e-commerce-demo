<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ImagesRelateProduct extends Model
{
    //
    protected $fillable = ['thumb_id', 'path'];
    
}
